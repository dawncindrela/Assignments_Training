package assignment;
import java.util.*;
import java.util.LinkedHashSet;

public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet L1=new LinkedHashSet ();
		L1.add(5);
		L1.add(7);
		L1.add(3.2f);
		L1.add(7.9f);
		L1.add('C');
		L1.add('T');
		L1.add(false);
		L1.add("Sohaum");
		L1.add("Ghosh");
		L1.remove(7);
		System.out.println(L1.contains(5));
		System.out.println(L1.contains("String"));
		System.out.println("The linked hashset is: "+L1);
		L1.clear();
		System.out.println("The linked hashset L1 is: "+L1);
		
		LinkedHashSet<Integer> L2=new LinkedHashSet<Integer> ();
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<10;i++) {
			L2.add(sc.nextInt());
		}
		L2.add(12);
		L2.add(11);
		L2.remove(8);
		System.out.println(L2.contains(5));
		System.out.println(L2.contains("String"));
		System.out.println("The linked hashset is: "+L2);
		L2.clear();
		System.out.println("The linked hashset L1 is: "+L2);
	}

}
