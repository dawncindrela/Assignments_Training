package assignment;
import java.util.*;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet t=new TreeSet();
		t.add("Python");
		t.add("Cpp");
		t.add("Java");
		t.add("JavaScript");
		t.add("Html");
		t.add("Css");
		System.out.println("The treeset is: "+t);
		t.remove("Html");
		t.remove("Css");
		System.out.println("The treeset is: "+t);
		t.add("C");
		t.add("Kotlin");
		t.add("Ruby");
		System.out.println("The treeset is: "+t);
		System.out.println(t.contains("Java"));
		t.clear();
		System.out.println("The treeset is: "+t);
	}

}
