package assignment;

public class Ecommerce {

	static int discount=5;
	static int electronicsDiscount=10;
	static int foodDiscount=30;
	
	String prodId,name,brand,category;
	double price;
	public Ecommerce(String prodId,String name,double price,String brand,String category) {
		this.prodId=prodId;
		this.name=name;
		this.price=price;
		this.brand=brand;
		this.category=category;
	}
	public void original() {
		double discountedPrice=price*(1-(discount/100.00));
		System.out.println(name+"(Original Discount 5%):"+discountedPrice);
	}
	public void printDetails() {
		int categoryDiscount=category.equalsIgnoreCase("electronics")?electronicsDiscount:foodDiscount;
		double finalPrice=price*(1-(categoryDiscount/100.00));
		System.out.println("ID:"+prodId+" Name:"+name+" Brand:"+brand+" Category:"+category+" Final Price:"+finalPrice);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ecommerce prod1=new Ecommerce("101","Laptop",50000,"Dell","electronics");
		Ecommerce prod2=new Ecommerce("102","Headphones",2000,"Sony","electronics");
		Ecommerce prod3=new Ecommerce("103","Chips",50,"Lays","food");
		Ecommerce prod4=new Ecommerce("104","Juice",100,"Tropicana","food");
		
		System.out.println("Original Discount (5% on all products):");
		prod1.original();
		prod2.original();
		prod3.original();
		prod4.original();
		
		System.out.println("\nAfter Festive Discount:");
		prod1.printDetails();
		prod2.printDetails();
		prod3.printDetails();
		prod4.printDetails();
	}

}
