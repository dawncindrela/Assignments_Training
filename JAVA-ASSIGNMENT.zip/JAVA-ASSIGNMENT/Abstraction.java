package assignment;

abstract class MNC {
    public abstract void leaves();
    public abstract void holidays();
    
    MNC() {
        System.out.println("MNC from constructor");
    }
    
    public void display() {
        System.out.println("MNC is displayed from method");
    }
}

abstract class Mindsprint extends MNC {
    @Override
    public void holidays() {
        System.out.println("Mindsprint holidays policy");
    }
}

class Hello extends Mindsprint {
    @Override
    public void leaves() {
        System.out.println("Hello leaves policy");
    }
    
    public void newMethod() {
        System.out.println("Hello's new method");
    }
}

public class Abstraction {
    public static void main(String[] args) {
        MNC obj = new Hello();
        obj.display();
        obj.leaves();
        obj.holidays();
    }
}
