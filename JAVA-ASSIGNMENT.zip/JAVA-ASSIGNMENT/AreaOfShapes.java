package assignment;

public class AreaOfShapes {
	public int calculate(int h,int b) {
		return (int)(h*b/2);
	}
	public int calculate(int radius) {
		return (int)3.14*radius*radius;
	}
	public float calculate(float l,float b) {
		return l*b;
	}
	public long calculate(long s) {
		return s*s;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AreaOfShapes a=new AreaOfShapes();
		int a1=a.calculate(5);
		System.out.println("Area of Circle="+a1);
		long s1=a.calculate(4l);
		System.out.println("Area of Square="+s1);
		int h1=7,b1=8;
		int r1=a.calculate(h1,b1);
		System.out.println("Area of Rhombus="+r1);
		float l=3.1f,b=6.2f;
		float rec1=a.calculate(l,b);
		System.out.println("Area of Rectangle="+rec1);
	}

}
