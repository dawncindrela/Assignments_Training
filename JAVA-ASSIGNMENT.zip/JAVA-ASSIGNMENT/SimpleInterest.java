package assignment;

public class SimpleInterest {
	public double calculateSI(double p, double r, int t) {
		double SI=(p*r*t)/100;
		return SI;
	}
	public void amountprint(double p,double s) {
		double a=p+s;
		System.out.println("Amount="+a);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double principle=100.01;
		double rate=9.2;
		int time=4;
		SimpleInterest s=new SimpleInterest();
		double si=s.calculateSI(principle,rate,time);
		System.out.println("SI="+si);
		s.amountprint(principle,si);
	}
}
