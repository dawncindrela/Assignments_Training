package assignment;

public class Calculate {
	public int calculate(int a,int b) {
		return a+b;
	}
	public float calculate(float a,float b) {
			return a-b;
	}
	public long calculate(long a,long b) {
			return a*b;
	}
	public double calculate(double a,double b) {
		return a/b;
	}
	public void checkEven(int x) {
		if (x%2==0) {
            System.out.println(x + " is even");
        } else {
            System.out.println(x + " is odd");
        }
	}
	public void checkPrime(int x) {
		int c=0;
		int i=x;
		while(i>=1) {
			if(x%i==0) c++;
			i--;
		}
		if(c==2) {
            System.out.println(x + " is prime");
        } else {
            System.out.println(x + " is non-prime");
        }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=10,y=20;
		float a=15.0f,b=7.2f;
		long m=1448L,n=600L;
		double p=20.6,q=5.2;
		int e=200;
		int pr=7;
		
		Calculate c=new Calculate();
		
		int a1=c.calculate(x,y);
		System.out.println("Sum="+a1);
		
		float a2=c.calculate(a,b);
		System.out.println("Difference="+a2);
		
		long a3=c.calculate(m,n);
		System.out.println("Product="+a3);
		
		double a4=c.calculate(p,q);
		System.out.println("Division="+a4);
		
		c.checkEven(e);
		c.checkPrime(pr);
	}

}
